// ينسخ التطبيق + مكتبة Excel محلياً إلى dist (يعمل بدون إنترنت 100%)
const fs = require('fs');
fs.rmSync('dist', { recursive: true, force: true });
fs.mkdirSync('dist', { recursive: true });
fs.copyFileSync('app/index.html', 'dist/index.html');
fs.copyFileSync('node_modules/xlsx/dist/xlsx.full.min.js', 'dist/xlsx.full.min.js');
console.log('dist جاهز');
