# AC معمل — تطبيق أندرويد (يعمل بدون إنترنت)

المتطلبات على جهازك: Node.js 18+ ، Android Studio (يشمل SDK و JDK 17).

## الخطوات
```
npm install
npm run build
npx cap add android
npm run icons          # يولّد أيقونات أندرويد من مجلد assets
npx cap sync android
cd android
./gradlew assembleDebug        # على ويندوز: gradlew.bat assembleDebug
```
الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`
(أو افتح مجلد android في Android Studio ثم Build > Build APK).

## ملاحظات
- `app/index.html` هو تطبيقك الأصلي مع تعديلات الأندرويد فقط (حفظ Excel/JSON في Documents/AC-Maamal + مشاركة واتساب).
- الطباعة: الـ WebView لا يطبع مباشرة، فيُحفظ ملف HTML للفاتورة ويُشارك لفتحه وطباعته من المتصفح.
- البيانات تُخزَّن في الهاتف (localStorage)؛ خذ نسخة احتياطية JSON دورياً.
